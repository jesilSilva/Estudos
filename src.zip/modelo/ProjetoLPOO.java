package modelo;

import java.util.Scanner;

import service.EsporteService;
import service.EventoService;
import service.LocalService;
import service.OrganizadorService;
import service.UsuarioService;
import ui.CategoriaUI;

public class ProjetoLPOO {

	public static void main(final String[] args) {
		int opcao = 0;

		final CategoriaUI categoriaUI = new CategoriaUI();
		final EsporteService esporteService = new EsporteService();
		final EventoService eventoService = new EventoService();
		final LocalService localService = new LocalService();
		final OrganizadorService organizadorService = new OrganizadorService();
		final UsuarioService usuarioService = new UsuarioService();
		final Scanner leitura = new Scanner(System.in);

		do {
			System.out.println("Bem vindo ao Team Catcher!");
			System.out.println("Escolha uma opção do menu que deseja acessar:");
			System.out.println("1 - Categoria");
			System.out.println("2 - Esporte");
			System.out.println("3 - Evento");
			System.out.println("4 - Local");
			System.out.println("5 - Organizador");
			System.out.println("6 - Usuario");
			System.out.println("7 - Sair");
			System.out.print("Digite a opção desejada:");
			opcao = leitura.nextInt();
			System.out.println("\n\n\n");

			switch (opcao) {
			case 1:

				switch (categoriaUI.consultarMenu()) {

				case 1:
					categoriaUI.cadastrar();
					break;
				case 2:
					categoriaUI.consultarTodos();
					break;
				case 3:
					categoriaUI.consultarPorCodigo();
					break;
				case 4:
					categoriaUI.alterar();
					break;
				case 5:
					categoriaUI.excluir();
					break;

				default:
					System.out.println("Esta não é uma opção válida!");
				}
				break;
			case 2:

				switch (esporteService.processaMenu()) {
				case 1:
					esporteService.cadastrar();
					break;
				case 2:
					esporteService.consultarTodos();
					break;
				case 3:
					esporteService.consultarPorCodigo();
					break;
				case 4:
					esporteService.alterar();
					break;
				case 5:
					esporteService.excluir();
					break;
				default:

					System.out.println("Esta não é uma opção válida!");
				}
				break;
			case 3:

				switch (eventoService.processaMenu()) {
				case 1:
					eventoService.cadastrar();
					break;
				case 2:
					eventoService.consultarTodos();
					break;
				case 3:
					eventoService.consultarPorNome();
					break;
				case 4:
					esporteService.alterar();
					break;
				case 5:
					esporteService.excluir();
					break;
				default:

					System.out.println("Esta não é uma opção válida!");
				}
				break;

			case 4:

				switch (localService.processaMenu()) {
				case 1:
					localService.cadastrar();
					break;
				case 2:
					localService.consultar();
					break;
				case 3:
					localService.consultarPorCep();
					break;
				case 4:
					localService.alterar();
					break;
				case 5:
					localService.excluir();
					break;
				default:

					System.out.println("Esta não é uma opção válida!");
				}
				break;
			case 5:

				switch (organizadorService.processaMenu()) {
				case 1:
					organizadorService.cadastrar();
					break;
				case 2:
					organizadorService.consultar();
					break;
				case 3:
					organizadorService.consultarPorCodigo();
					break;
				case 4:
					organizadorService.alterar();
					break;
				case 5:
					organizadorService.excluir();
					break;
				default:

					System.out.println("Esta não é uma opção válida!");
				}
				break;
			case 6:

				switch (usuarioService.processaMenu()) {
				case 1:
					usuarioService.cadastrar();
					break;
				case 2:
					usuarioService.consultar();
					break;
				case 3:
					usuarioService.consultarPorCodigo();
					break;
				case 4:
					usuarioService.alterar();
					break;
				case 5:
					usuarioService.excluir();
					break;

				default:
					System.out.println("Esta não é uma opção válida!");
				}
			}
		} while (opcao != 7);

		System.out.println("Volte sempre para usar o sistem Team Catcher!");
	}
}
