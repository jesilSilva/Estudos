package entity;

public interface Entity {
	public int getCodigo();

	public void setCodigo(int codigo);

}
