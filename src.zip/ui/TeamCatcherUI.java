package ui;

import entity.MenuConsoleEntity;
import service.TeamCatcherService;

public class TeamCatcherUI {

	TeamCatcherService teamCatcherService;

	public TeamCatcherUI() {
		this.teamCatcherService = new TeamCatcherService();
	}

	public int consultarMenu() {
		final MenuConsoleEntity menuConsoleEntity = this.teamCatcherService.consultarMenu();
		final MenuConsoleUITemplate menuConsoleUITemplate = new MenuConsoleUITemplate(menuConsoleEntity);
		menuConsoleUITemplate.desenharMenu();
		return menuConsoleUITemplate.receberOpcaoUsuario();
	}

}
