package ui;

import java.util.List;
import java.util.Scanner;

import entity.CategoriaEntity;
import service.CategoriaService;

public class CategoriaUI {

	CategoriaService categoriaService;

	public CategoriaUI() {
		this.categoriaService = new CategoriaService();
	}

	public int consultarMenu() {
		final Scanner leitorCategoria = new Scanner(System.in);

		final List<String> menu = this.categoriaService.consultarMenu();
		for (final String string : menu) {
			System.out.println(string);
		}

		final int opcao = leitorCategoria.nextInt();

		return opcao;
	}

	public void cadastrar() {

		final Scanner leitorCategoria = new Scanner(System.in);
		System.out.println("************Cadastro categoria**************");

		System.out.println("Informe o código:");
		final int codigo = leitorCategoria.nextInt();

		System.out.println("Informe o nome da categoria:");
		final String nome = leitorCategoria.next();

		System.out.println("Informe caracteristica");
		final String caracteristicas = leitorCategoria.next();

		System.out.println("Informe o esporte:");
		final String esporte = leitorCategoria.next();

		System.out.println("Informe a restrição:");
		final String restricao = leitorCategoria.next();

		final String mensagem = this.categoriaService.cadastrar(codigo, nome, caracteristicas, esporte, restricao);

		System.out.println(mensagem);
		System.out.println("\n\n\n");
	}

	public void consultarTodos() {

		final List<CategoriaEntity> categorias = this.categoriaService.consultarTodos();

		if (categorias.isEmpty()) {
			System.out.println("Não existe categorias cadastradas!");
			System.out.println("\n\n\n");
		} else {
			for (int i = 0; i < categorias.size(); i++) {

				System.out.println("\n\n\n\n\n\n\n\n\n");
				System.out.println("******Consulta Categoria********");
				System.out.println("********  Dados da Categoria ********");
				System.out.println("Código da categoria:" + categorias.get(i).getCodigo());
				System.out.println("Nome da categoria: " + categorias.get(i).getNome());
				System.out.println("Caracteristicas:" + categorias.get(i).getCaracteristicas());
				System.out.println("Categoria: " + categorias.get(i).getEsporte());
				System.out.println("Restrição: " + categorias.get(i).getRestricao());
				System.out.println("**********************************");
				System.out.println("\n\n\n");
			}
		}
	}

	public void consultarPorCodigo() {

		final Scanner leitorCategoria = new Scanner(System.in);
		System.out.println("************Consultar por c�digo da categoria**************");

		System.out.println("Informe o código:");
		final int codigo = leitorCategoria.nextInt();

		final CategoriaEntity categoria = this.categoriaService.consultarPorCodigo(codigo);

		if (categoria == null) {
			System.out.println("Não existe categorias cadastradas!");
			System.out.println("\n\n\n");
		} else {

			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Categoria********");
			System.out.println("********  Dados da Categoria ********");
			System.out.println("Código da categoria:" + categoria.getCodigo());
			System.out.println("Nome da categoria: " + categoria.getNome());
			System.out.println("Caracteristicas:" + categoria.getCaracteristicas());
			System.out.println("Categoria: " + categoria.getEsporte());
			System.out.println("Restrição: " + categoria.getRestricao());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}
	}

	public void excluir() {

		final Scanner leitorCategoria = new Scanner(System.in);

		System.out.println("****************Exclusão da Categoria********************");
		System.out.println("Informe o código da categoria que deseja excluir:");

		final int codigo = leitorCategoria.nextInt();

		final String mensagem = this.categoriaService.excluir(codigo);
		System.out.println(mensagem);
	}

	public void alterar() {

		final Scanner leitorCategoria = new Scanner(System.in);

		System.out.println("****************Alteração da categoria********************");

		System.out.println("Informe o código da categoria:");
		final int codigo = leitorCategoria.nextInt();

		System.out.println("Informe o novo nome:");
		final String nome = leitorCategoria.next();

		System.out.println("Informe a caracteristica:");
		final String caracteristicas = leitorCategoria.next();

		System.out.println("Informe o esporte:");
		final String esporte = leitorCategoria.next();

		System.out.println("Informe a restrição:");
		final String restricao = leitorCategoria.next();

		final String mensagem = this.categoriaService.alterar(codigo, nome, caracteristicas, esporte, restricao);

		System.out.println(mensagem);

	}

}