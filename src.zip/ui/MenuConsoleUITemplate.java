package ui;

import java.util.Scanner;

import entity.MenuConsoleEntity;

public class MenuConsoleUITemplate {

	MenuConsoleEntity menuConsoleEntity;

	public MenuConsoleUITemplate(final MenuConsoleEntity menuConsoleEntity) {
		this.menuConsoleEntity = menuConsoleEntity;
	}

	public void desenharMenu() {
		System.out.println("+----------------------------------------------+");
		System.out.println("|" + this.menuConsoleEntity.getTitle() + "\t\t\t\t+");
		System.out.println("+----------------------------------------------+");

		System.out.println("|Escolha sua opção:\t\t\t\t|");
		for (final String string : this.menuConsoleEntity.getOpcao()) {
			System.out.println("|" + string + "\t\t|");
		}
		System.out.println("+----------------------------------------------+");
	}

	public int receberOpcaoUsuario() {

		System.out.println("Digite a opção desejada:");
		final Scanner leitor = new Scanner(System.in);
		int opcao = 0;
		if (leitor.hasNextInt()) {
			opcao = leitor.nextInt();
		} else {
			System.out.println("Valor inválido! É preciso digitar um número.");
			return this.receberOpcaoUsuario();
		}
		return opcao;
	}
}