package repository;

import java.util.ArrayList;
import java.util.List;

import entity.OrganizadorEntity;

public class OrganizadorRepository implements Repository<OrganizadorEntity> {

	List<OrganizadorEntity> organizadorBD;
	List<String> opcaoMenuBD;

	public OrganizadorRepository() {
		this.organizadorBD = new ArrayList<OrganizadorEntity>();
		this.opcaoMenuBD = new ArrayList<String>();

		this.opcaoMenuBD.add("Bem vindo as funções do organizador!");
		this.opcaoMenuBD.add("Escolha uma opção abaixo.");
		this.opcaoMenuBD.add("1 - Cadastrar organizador");
		this.opcaoMenuBD.add("2 - Consultar organizador");
		this.opcaoMenuBD.add("3 - Consultar por c�digo");
		this.opcaoMenuBD.add("4 - Alterar organizador");
		this.opcaoMenuBD.add("5 - Excluir organizador");
		this.opcaoMenuBD.add("Digite a opção desejada:");
	}

	@Override
	public void incluir(final OrganizadorEntity organizadorEntity) {

		this.organizadorBD.add(organizadorEntity);
	}

	@Override
	public List<OrganizadorEntity> consultarTodos() {
		return this.organizadorBD;
	}

	@Override
	public OrganizadorEntity consultarPorCodigo(final int codigo) {
		for (final OrganizadorEntity organizadorEntity : this.organizadorBD) {
			if (codigo == organizadorEntity.getCodigo()) {
				return organizadorEntity;
			}
		}
		return null;
	}

	@Override
	public void excluir(final OrganizadorEntity organizadorEntity) {
		if (organizadorEntity != null) {
			this.organizadorBD.remove(organizadorEntity);
		}
	}

	@Override
	public void alterar(final OrganizadorEntity organizadorEntity) {
		if (organizadorEntity != null) {
			this.organizadorBD.add(organizadorEntity);
		}
	}

	@Override
	public List<String> consultarMenu() {

		return this.opcaoMenuBD;
	}
}
