package repository;

import java.util.ArrayList;
import java.util.List;

import entity.EsporteEntity;

public class EsporteRepository implements Repository<EsporteEntity> {

	List<EsporteEntity> esporteBD;
	List<String> opcaoMenuBD;

	public EsporteRepository() {
		this.esporteBD = new ArrayList<EsporteEntity>();

		this.opcaoMenuBD = new ArrayList<String>();
		this.opcaoMenuBD.add("Bem vindo as funções do esporte!");
		this.opcaoMenuBD.add("Escolha uma opção abaixo.");
		this.opcaoMenuBD.add("1 - Cadastrar esporte");
		this.opcaoMenuBD.add("2 - Consultar todos esportes");
		this.opcaoMenuBD.add("3 - Consultar por c�digo do esporte");
		this.opcaoMenuBD.add("4 - Alterar esporte");
		this.opcaoMenuBD.add("5 - Excluir esporte");
		this.opcaoMenuBD.add("Digite a opção desejada:");

	}

	@Override
	public void incluir(final EsporteEntity esporteEntity) {
		this.esporteBD.add(esporteEntity);
	}

	@Override
	public List<EsporteEntity> consultarTodos() {
		return this.esporteBD;
	}

	@Override
	public EsporteEntity consultarPorCodigo(final int codigo) {

		for (final EsporteEntity esporteEntity : this.esporteBD) {
			if (codigo == esporteEntity.getCodigo()) {
				return esporteEntity;
			}
		}
		return null;
	}

	@Override
	public void excluir(final EsporteEntity esporteEntity) {

		if (esporteEntity != null) {
			this.esporteBD.remove(esporteEntity);
		}
	}

	@Override
	public void alterar(final EsporteEntity esporteEntity) {
		this.esporteBD.add(esporteEntity);
	}

	@Override
	public List<String> consultarMenu() {
		return this.opcaoMenuBD;
	}
}