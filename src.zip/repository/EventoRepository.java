package repository;

import java.util.ArrayList;
import java.util.List;

import entity.EventoEntity;

public class EventoRepository implements Repository<EventoEntity> {

	List<EventoEntity> eventoBD;
	List<String> opcaoMenuBD;

	public EventoRepository() {
		this.eventoBD = new ArrayList<EventoEntity>();
		this.opcaoMenuBD = new ArrayList<String>();
		this.opcaoMenuBD.add("Bem vindo as funções do evento!");
		this.opcaoMenuBD.add("Escolha uma opção abaixo.");
		this.opcaoMenuBD.add("1 - Cadastrar evento");
		this.opcaoMenuBD.add("2 - Consultar evento");
		this.opcaoMenuBD.add("3 - Consultar por nome do evento");
		this.opcaoMenuBD.add("4 - Alterar evento");
		this.opcaoMenuBD.add("5 - Excluir evento");
		this.opcaoMenuBD.add("Digite a opção desejada:");

	}

	@Override
	public void incluir(final EventoEntity eventoEntity) {
		this.eventoBD.add(eventoEntity);

	}

	@Override
	public List<EventoEntity> consultarTodos() {
		return this.eventoBD;
	}

	@Override
	public EventoEntity consultarPorCodigo(final int codigo) {

		for (final EventoEntity eventoEntity : this.eventoBD) {
			if (codigo == eventoEntity.getCodigo()) {
				return eventoEntity;
			}
		}
		return null;
	}

	public EventoEntity consultarPorNome(final String nome) {
		for (final EventoEntity eventoEntity : this.eventoBD) {

			if (nome.equals(eventoEntity.getNome())) {
				return eventoEntity;
			}

		}
		return null;
	}

	@Override
	public void excluir(final EventoEntity eventoEntity) {

		if (eventoEntity != null) {
			this.eventoBD.remove(eventoEntity);
		}

	}

	@Override
	public void alterar(final EventoEntity eventoEntity) {
		if (eventoEntity != null) {
			this.eventoBD.add(eventoEntity);
		}
	}

	@Override
	public List<String> consultarMenu() {

		return this.opcaoMenuBD;
	}

}
