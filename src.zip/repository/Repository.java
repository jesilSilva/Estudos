package repository;

import java.util.List;

public interface Repository<Entity> {

	public void incluir(final Entity entity);

	public void excluir(final Entity entity);

	public void alterar(final Entity entity);

	public List<Entity> consultarTodos();

	public Entity consultarPorCodigo(final int codigo);

	public List<String> consultarMenu();
}