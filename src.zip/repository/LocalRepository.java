package repository;

import java.util.ArrayList;
import java.util.List;

import entity.LocalEntity;

public class LocalRepository implements Repository<LocalEntity> {

	List<LocalEntity> localBD;
	List<String> opcaoMenuBD;

	public LocalRepository() {

		this.localBD = new ArrayList<LocalEntity>();

		this.opcaoMenuBD = new ArrayList<String>();
		this.opcaoMenuBD.add("Bem vindo as funções do local!");
		this.opcaoMenuBD.add("Escolha uma opção abaixo.");
		this.opcaoMenuBD.add("1 - Cadastrar local");
		this.opcaoMenuBD.add("2 - Consultar local");
		this.opcaoMenuBD.add("3 - Consultar local por cep");
		this.opcaoMenuBD.add("4 - Alterar local");
		this.opcaoMenuBD.add("5 - Excluir local");
		this.opcaoMenuBD.add("Digite a opção desejada:");
	}

	@Override
	public void incluir(final LocalEntity localEntity) {
		this.localBD.add(localEntity);
	}

	@Override
	public List<LocalEntity> consultarTodos() {
		return this.localBD;
	}

	@Override
	public LocalEntity consultarPorCodigo(final int codigo) {

		for (final LocalEntity localEntity : this.localBD) {
			if (codigo == localEntity.getCodigo()) {
				return localEntity;
			}
		}
		return null;
	}

	public LocalEntity consultarPorCep(final int cep) {
		for (final LocalEntity localEntity : this.localBD) {

			if (cep == localEntity.getCep()) {
				return localEntity;
			}

		}
		return null;
	}

	@Override
	public void excluir(final LocalEntity localEntity) {

		if (localEntity != null) {
			this.localBD.remove(localEntity);
		}
	}

	@Override
	public void alterar(final LocalEntity localEntity) {

		if (localEntity != null) {
			this.localBD.remove(localEntity);

		}
	}

	@Override
	public List<String> consultarMenu() {

		return this.opcaoMenuBD;
	}

}
