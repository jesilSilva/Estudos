package repository;

import java.util.ArrayList;
import java.util.List;

import entity.UsuarioEntity;

public class UsuarioRepository implements Repository<UsuarioEntity> {

	List<UsuarioEntity> usuarioBD;
	List<String> opcaoMenuBD;

	public UsuarioRepository() {
		this.usuarioBD = new ArrayList<UsuarioEntity>();

		this.opcaoMenuBD = new ArrayList<String>();
		this.opcaoMenuBD.add("Bem vindo as funções do usuário!");
		this.opcaoMenuBD.add("Escolha uma opção abaixo.");
		this.opcaoMenuBD.add("1 - Cadastrar usuário");
		this.opcaoMenuBD.add("2 - Consultar usuário");
		this.opcaoMenuBD.add("3 - Consultar usu�rio por c�digo");
		this.opcaoMenuBD.add("4 - Alterar usuário");
		this.opcaoMenuBD.add("5 - Excluir usuário");
		this.opcaoMenuBD.add("Digite a opção desejada:");

	}

	@Override
	public void incluir(final UsuarioEntity usuarioEntity) {
		this.usuarioBD.add(usuarioEntity);
	}

	@Override
	public List<UsuarioEntity> consultarTodos() {
		return this.usuarioBD;
	}

	@Override
	public UsuarioEntity consultarPorCodigo(final int codigo) {
		for (final UsuarioEntity usuarioEntity : this.usuarioBD) {

			if (codigo == usuarioEntity.getCodigo()) {
				return usuarioEntity;
			}

		}
		return null;
	}

	@Override
	public void excluir(final UsuarioEntity usuarioEntity) {

		if (usuarioEntity != null) {
			this.usuarioBD.remove(usuarioEntity);
		}
	}

	@Override
	public void alterar(final UsuarioEntity usuarioEntity) {
		this.usuarioBD.add(usuarioEntity);
	}

	@Override
	public List<String> consultarMenu() {
		return this.opcaoMenuBD;
	}

}