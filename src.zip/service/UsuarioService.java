package service;

import java.util.List;
import java.util.Scanner;

import entity.UsuarioEntity;
import repository.UsuarioRepository;

public class UsuarioService {

	UsuarioRepository usuarioRepository;

	public UsuarioService() {
		this.usuarioRepository = new UsuarioRepository();
	}

	public int processaMenu() {
		final Scanner leitorUsuario = new Scanner(System.in);

		final List<String> menu = this.usuarioRepository.consultarMenu();

		for (final String string : menu) {

			System.out.println(string);

		}
		final int opcao = leitorUsuario.nextInt();
		return opcao;
	}

	public void cadastrar() {

		final Scanner leitorUsuario = new Scanner(System.in);
		System.out.println("************Cadastro Usuário**************");
		System.out.println("Informe o nome do usuário:");
		final String nome = leitorUsuario.next();
		System.out.println("Informe o e-mail:");
		final String email = leitorUsuario.next();
		System.out.println("Informe o código do usuário:");
		final int codigo = leitorUsuario.nextInt();
		System.out.println("Informe a senha:");
		final String senha = leitorUsuario.next();
		System.out.println("Informe o telefone do usuário:");
		final int telefone = leitorUsuario.nextInt();
		System.out.println("Informe a idade do usuário:");
		final int idade = leitorUsuario.nextInt();

		final UsuarioEntity usuarioEntity = new UsuarioEntity(nome, email, codigo, senha, telefone, idade);

		this.usuarioRepository.incluir(usuarioEntity);
	}

	public List<UsuarioEntity> consultar() {

		final List<UsuarioEntity> usuarios = this.usuarioRepository.consultarTodos();

		for (int i = 0; i < usuarios.size(); i++) {

			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Usuário********");
			System.out.println("********  Dados do Usuário ********");
			System.out.println("Nome: " + usuarios.get(i).getNome());
			System.out.println("E-mail:" + usuarios.get(i).getEmail());
			System.out.println("Código do usuário:" + usuarios.get(i).getCodigo());
			System.out.println("Senha: " + usuarios.get(i).getSenha());
			System.out.println("Telefone: " + usuarios.get(i).getTelefone());
			System.out.println("Idade:" + usuarios.get(i).getIdade());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}
		if (usuarios.isEmpty()) {
			System.out.println("Não existe usuários cadastrados!");
			System.out.println("\n\n\n");
		}

		return usuarios;
	}

	public UsuarioEntity consultarPorCodigo() {

		final Scanner leitorUsuario = new Scanner(System.in);
		System.out.println("************Consultar por c�digo**************");

		System.out.println("informe o c�digo do usu�rio:");
		final int codigo = leitorUsuario.nextInt();

		final UsuarioEntity usuarios = this.usuarioRepository.consultarPorCodigo(codigo);

		if (usuarios == null) {
			System.out.println("N�o existe usu�rios com esse c�digo!");
			System.out.print("\n\n\n\n\n");
		} else {
			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Usuário********");
			System.out.println("********  Dados do Usuário ********");
			System.out.println("Nome: " + usuarios.getNome());
			System.out.println("E-mail:" + usuarios.getEmail());
			System.out.println("Código do usuário:" + usuarios.getCodigo());
			System.out.println("Senha: " + usuarios.getSenha());
			System.out.println("Telefone: " + usuarios.getTelefone());
			System.out.println("Idade:" + usuarios.getIdade());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}

		return usuarios;
	}

	public void excluir() {
		final Scanner leitorUsuario = new Scanner(System.in);
		System.out.println("****************Exclusão do usuário********************");
		System.out.println("Informe o código do usuário que deseja excluir:");
		final int codigo = leitorUsuario.nextInt();

		final UsuarioEntity usuarios = this.usuarioRepository.consultarPorCodigo(codigo);

		if (usuarios.getCodigo() == codigo) {
			this.usuarioRepository.excluir(usuarios);
			System.out.println("O registro foi deletado com sucesso!");
		}
	}

	public UsuarioEntity alterar() {
		final Scanner leitorUsuario = new Scanner(System.in);
		System.out.println("****************Alteração do usuário********************");
		System.out.println("Informe o código do usuário que deseja alterar:");
		final int codigo = leitorUsuario.nextInt();

		final UsuarioEntity usuarioEntity = this.usuarioRepository.consultarPorCodigo(codigo);

		if (usuarioEntity.getCodigo() == codigo) {
			System.out.println("Informe o novo nome:");
			usuarioEntity.setNome(leitorUsuario.next());
			System.out.println("Informe o e-mail:");
			usuarioEntity.setEmail(leitorUsuario.next());
			System.out.println("Informe o código do usuário:");
			usuarioEntity.setCodigo(leitorUsuario.nextInt());
			System.out.println("Informe a senha:");
			usuarioEntity.setSenha(leitorUsuario.next());
			System.out.println("Informe o telefone:");
			usuarioEntity.setTelefone(leitorUsuario.nextInt());
			System.out.println("Informe a idade:");
			usuarioEntity.setIdade(leitorUsuario.nextInt());

			System.out.println("Alterado com Sucesso");

		} else {
			System.out.println("Não existe usuários com esse código!");
		}

		return usuarioEntity;
	}

}