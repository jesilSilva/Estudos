package service;

import java.util.List;

import entity.CategoriaEntity;
import repository.CategoriaRepository;

public class CategoriaService {

	CategoriaRepository categoriaRepository;

	public CategoriaService() {
		this.categoriaRepository = new CategoriaRepository();
	}

	public List<String> consultarMenu() {

		final List<String> menu = this.categoriaRepository.consultarMenu();
		return menu;
	}

	public String cadastrar(final int codigo, final String nome, final String caracteristicas, final String esporte,
			final String restricao) {

		final CategoriaEntity categoriaEntity = new CategoriaEntity(codigo, nome, caracteristicas, esporte, restricao);

		this.categoriaRepository.incluir(categoriaEntity);

		return "Categoria cadastrada com sucesso!";
	}

	public List<CategoriaEntity> consultarTodos() {

		final List<CategoriaEntity> categorias = this.categoriaRepository.consultarTodos();

		return categorias;
	}

	public CategoriaEntity consultarPorCodigo(final int codigo) {

		final CategoriaEntity categoria = this.categoriaRepository.consultarPorCodigo(codigo);

		return categoria;
	}

	public String excluir(final int codigo) {

		final CategoriaEntity categoriaEntity = this.categoriaRepository.consultarPorCodigo(codigo);

		String mensagem = null;

		if (categoriaEntity != null) {
			this.categoriaRepository.excluir(categoriaEntity);
			mensagem = "O registro foi deletado com sucesso!";
		}
		return mensagem;
	}

	public String alterar(final int codigo, final String nome, final String caracteristicas, final String esporte,
			final String restricao) {
		String mensagem = null;
		final CategoriaEntity categoriaEntity = this.categoriaRepository.consultarPorCodigo(codigo);

		if (categoriaEntity != null) {
			categoriaEntity.setCodigo(codigo);

			categoriaEntity.setNome(nome);

			categoriaEntity.setCaracteristicas(caracteristicas);

			categoriaEntity.setEsporte(esporte);

			categoriaEntity.setRestricao(restricao);

			this.categoriaRepository.alterar(categoriaEntity);

			mensagem = "Alterado com Sucesso";

		} else {
			mensagem = "Não existe categorias com esse código!";
		}
		return mensagem;
	}
}