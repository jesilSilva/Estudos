package service;

import java.util.List;
import java.util.Scanner;

import entity.EventoEntity;
import repository.EventoRepository;

public class EventoService {

	EventoRepository eventoRepository;

	public EventoService() {
		this.eventoRepository = new EventoRepository();
	}

	public int processaMenu() {
		final Scanner leitorEvento = new Scanner(System.in);
		final List<String> menu = this.eventoRepository.consultarMenu();

		for (final String string : menu) {

			System.out.println(string);

		}
		final int opcao = leitorEvento.nextInt();
		return opcao;
	}

	public void cadastrar() {

		final Scanner leitorEvento = new Scanner(System.in);
		System.out.println("************Cadastro Evento**************");

		System.out.println("Informe o c�digo do evento:");
		final int codigo = leitorEvento.nextInt();
		System.out.println("Informe o nome do Evento:");
		final String nome = leitorEvento.next();
		System.out.println("Informe a data do evento:");
		final String data = leitorEvento.next();
		System.out.println("Informe o local do evento:");
		final String local = leitorEvento.next();
		System.out.println("Informe o horário do evento:");
		final String horario = leitorEvento.next();
		System.out.println("Informe o custo do evento:");
		final Double custo = leitorEvento.nextDouble();

		final EventoEntity eventoEntity = new EventoEntity(codigo, nome, data, local, horario, custo);

		this.eventoRepository.incluir(eventoEntity);
	}

	public List<EventoEntity> consultarTodos() {
		final List<EventoEntity> eventos = this.eventoRepository.consultarTodos();

		for (int i = 0; i < eventos.size(); i++) {
			if (eventos.isEmpty()) {
				System.out.println("Não existe eventos cadastrados!");
				System.out.println("\n\n\n");
			} else {

				System.out.println("\n\n\n\n\n\n\n\n\n");
				System.out.println("******Consulta Evento********");
				System.out.println("********  Dados do Evento ********");
				System.out.println("Nome do evento: " + eventos.get(i).getNome());
				System.out.println("Data:" + eventos.get(i).getData());
				System.out.println("Local:" + eventos.get(i).getLocal());
				System.out.println("Horário: " + eventos.get(i).getHorario());
				System.out.println("Custo: " + eventos.get(i).getCusto());
				System.out.println("**********************************");
				System.out.println("\n\n\n");

			}
		}

		return eventos;
	}

	public EventoEntity consultarPorNome() {

		final Scanner leitorEvento = new Scanner(System.in);

		System.out.println("************Consultar por nome do evento**************");

		System.out.println("Informe o código:");
		final String nome = leitorEvento.next();

		final EventoEntity eventos = this.eventoRepository.consultarPorNome(nome);

		if (eventos == null) {
			System.out.println("Não existe eventos cadastrados!");
			System.out.println("\n\n\n");
		} else {
			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Evento********");
			System.out.println("********  Dados do Evento ********");
			System.out.println("Nome do evento: " + eventos.getNome());
			System.out.println("Data:" + eventos.getData());
			System.out.println("Local:" + eventos.getLocal());
			System.out.println("Horário: " + eventos.getHorario());
			System.out.println("Custo: " + eventos.getCusto());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}
		return eventos;
	}

	public void excluir() {
		final Scanner leitorEvento = new Scanner(System.in);
		System.out.println("****************Exclusão do evento********************");
		System.out.println("Informe nome do evento que deseja excluir:");
		final String nome = leitorEvento.next();

		final EventoEntity eventoEntity = this.eventoRepository.consultarPorNome(nome);

		if (eventoEntity != null) {
			this.eventoRepository.excluir(eventoEntity);
			System.out.println("O registro foi deletado com sucesso!");
		}
	}

	public void alterar() {
		final Scanner leitorEvento = new Scanner(System.in);
		System.out.println("****************Alteração do evento********************");
		System.out.println("Informe o nome do evento que deseja alterar:");
		final String nome = leitorEvento.next();

		final EventoEntity eventoEntity = this.eventoRepository.consultarPorNome(nome);

		if (eventoEntity != null) {
			System.out.println("Informe o novo nome:");
			eventoEntity.setNome(leitorEvento.next());
			System.out.println("Informe a data:");
			eventoEntity.setData(leitorEvento.next());
			System.out.println("Informe o local:");
			eventoEntity.setLocal(leitorEvento.next());
			System.out.println("Informe o horário:");
			eventoEntity.setHorario(leitorEvento.next());
			System.out.println("Informe o custo :");
			eventoEntity.setCusto(leitorEvento.nextDouble());
			this.eventoRepository.alterar(eventoEntity);
			System.out.println("Alterado com Sucesso");

		} else {
			System.out.println("Não existe evento com esse nome!");
		}
	}
}
