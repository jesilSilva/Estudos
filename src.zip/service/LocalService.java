package service;

import java.util.List;
import java.util.Scanner;

import entity.LocalEntity;
import repository.LocalRepository;

public class LocalService {

	LocalRepository localRepository;

	public LocalService() {
		this.localRepository = new LocalRepository();
	}

	public int processaMenu() {
		final Scanner leitorLocal = new Scanner(System.in);

		final List<String> menu = this.localRepository.consultarMenu();

		for (final String string : menu) {
			System.out.println(string);

		}
		final int opcao = leitorLocal.nextInt();
		return opcao;
	}

	public void cadastrar() {

		final Scanner leitorLocal = new Scanner(System.in);
		System.out.println("************Cadastro Local**************");

		System.out.print("Informe o c�digo do local:");
		final int codigo = leitorLocal.nextInt();
		System.out.println("Informe o endereço do local:");
		final String endereco = leitorLocal.next();
		System.out.println("Informe o número:");
		final int numero = leitorLocal.nextInt();
		System.out.println("Informe o bairro:");
		final String bairro = leitorLocal.next();
		System.out.println("Informe o complemento:");
		final String complemento = leitorLocal.next();
		System.out.println("Informe o CEP:");
		final int cep = leitorLocal.nextInt();
		final LocalEntity localEntity = new LocalEntity(codigo, endereco, numero, bairro, complemento, cep);
		this.localRepository.incluir(localEntity);
	}

	public List<LocalEntity> consultar() {

		final List<LocalEntity> locais = this.localRepository.consultarTodos();

		if (locais.isEmpty()) {
			System.out.println("Não existe locais cadastrados!");
			System.out.println("\n\n\n");
		} else {
			for (int i = 0; i < locais.size(); i++) {

				System.out.println("\n\n\n\n\n\n\n\n\n");
				System.out.println("******Consulta Local********");
				System.out.println("********  Dados do Local ********");
				System.out.println("Endereço: " + locais.get(i).getEndereco());
				System.out.println("Número:" + locais.get(i).getNumero());
				System.out.println("Bairro:" + locais.get(i).getBairro());
				System.out.println("Complemento: " + locais.get(i).getComplemento());
				System.out.println("CEP: " + locais.get(i).getCep());
				System.out.println("**********************************");
				System.out.println("\n\n\n");

			}
		}

		return locais;
	}

	public LocalEntity consultarPorCep() {
		final Scanner leitorLocal = new Scanner(System.in);
		System.out.println("************Consultar por CEP**************");
		System.out.println("informe o cep do local:");
		final int cep = leitorLocal.nextInt();

		final LocalEntity locais = this.localRepository.consultarPorCep(cep);

		if (locais == null) {
			System.out.println("Não existe locais cadastrados com esse cep!");
			System.out.println("\n\n\n");
		} else {
			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Local********");
			System.out.println("********  Dados do Local ********");
			System.out.println("Endereço: " + locais.getEndereco());
			System.out.println("Número:" + locais.getNumero());
			System.out.println("Bairro:" + locais.getBairro());
			System.out.println("Complemento: " + locais.getComplemento());
			System.out.println("CEP: " + locais.getCep());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}
		return locais;
	}

	public void excluir() {
		final Scanner leitorLocal = new Scanner(System.in);
		System.out.println("****************Exclusão do Local********************");
		System.out.println("Informe o cep que deseja excluir endereço:");
		final int cep = leitorLocal.nextInt();

		final LocalEntity localEntity = this.localRepository.consultarPorCep(cep);

		if (localEntity.getCep() == cep) {
			this.localRepository.excluir(localEntity);
			System.out.println("O registro foi deletado com sucesso!");
		}

	}

	public void alterar() {
		final Scanner leitorLocal = new Scanner(System.in);
		System.out.println("****************Alteração do local********************");
		System.out.println("Informe o CEP do local que deseja alterar:");
		final int cep = leitorLocal.nextInt();

		final LocalEntity localEntity = this.localRepository.consultarPorCep(cep);

		if (localEntity != null) {
			System.out.println("Informe o novo endereço:");
			localEntity.setEndereco(leitorLocal.next());
			System.out.println("Informe o número:");
			localEntity.setNumero(leitorLocal.nextInt());
			System.out.println("Informe o bairro:");
			localEntity.setBairro(leitorLocal.next());
			System.out.println("Informe o complemento:");
			localEntity.setComplemento(leitorLocal.next());
			System.out.println("Informe o CEP :");
			localEntity.setCep(leitorLocal.nextInt());
			this.localRepository.alterar(localEntity);
			System.out.println("Alterado com Sucesso");

		} else {
			System.out.println("Não existe locais com esse CEP!");
		}
	}

}
