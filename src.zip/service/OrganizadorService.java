package service;

import java.util.List;
import java.util.Scanner;

import entity.OrganizadorEntity;
import repository.OrganizadorRepository;

public class OrganizadorService {

	OrganizadorRepository organizadorRepository;

	public OrganizadorService() {
		this.organizadorRepository = new OrganizadorRepository();
	}

	public int processaMenu() {
		final Scanner leitorOrganizador = new Scanner(System.in);
		final List<String> menu = this.organizadorRepository.consultarMenu();

		for (final String string : menu) {
			System.out.println(string);
		}
		final int opcao = leitorOrganizador.nextInt();

		return opcao;
	}

	public void cadastrar() {

		final Scanner leitorOrganizador = new Scanner(System.in);
		System.out.println("************Cadastro Organizador**************");

		System.out.println("Informe o nome do organizador:");
		final String nome = leitorOrganizador.next();
		System.out.println("Informe o código do organizador:");
		final int codigo = leitorOrganizador.nextInt();
		System.out.println("Informe o Evento criado:");
		final String evento = leitorOrganizador.next();
		System.out.println("Informe a descricao:");
		final String descricao = leitorOrganizador.next();
		System.out.println("Informe o nível do organizador:");
		final int nivel = leitorOrganizador.nextInt();

		final OrganizadorEntity organizadorEntity = new OrganizadorEntity(nome, codigo, evento, descricao, nivel);
		this.organizadorRepository.incluir(organizadorEntity);
	}

	public List<OrganizadorEntity> consultar() {

		final List<OrganizadorEntity> locais = this.organizadorRepository.consultarTodos();

		for (int i = 0; i < locais.size(); i++) {

			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Organizador********");
			System.out.println("********  Dados do Organizador ********");
			System.out.println("Nome: " + locais.get(i).getNome());
			System.out.println("Codigo:" + locais.get(i).getCodigo());
			System.out.println("Evento:" + locais.get(i).getEventoCriado());
			System.out.println("Descricao: " + locais.get(i).getDescricao());
			System.out.println("Nivel do organizador: " + locais.get(i).getNivelOrganizador());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}
		if (locais.isEmpty()) {
			System.out.println("Nao existe organizadores cadastrados!");
			System.out.println("\n\n\n");
		}

		return locais;
	}

	public OrganizadorEntity consultarPorCodigo() {

		final Scanner leitorOrganizador = new Scanner(System.in);
		System.out.println("************Consultar por c�digo**************");
		System.out.println("informe o c�digo do organizador:");
		final int codigo = leitorOrganizador.nextInt();

		final OrganizadorEntity organizadores = this.organizadorRepository.consultarPorCodigo(codigo);

		if (organizadores == null) {
			System.out.println("N�o existe organizadores com esse c�digo!");
			System.out.print("\n\n\n\n\n");
		} else {
			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Organizador********");
			System.out.println("********  Dados do Organizador ********");
			System.out.println("Nome: " + organizadores.getNome());
			System.out.println("Codigo:" + organizadores.getCodigo());
			System.out.println("Evento:" + organizadores.getEventoCriado());
			System.out.println("Descricao: " + organizadores.getDescricao());
			System.out.println("Nivel do organizador: " + organizadores.getNivelOrganizador());
			System.out.println("**********************************");
			System.out.println("\n\n\n");

		}

		return organizadores;
	}

	public void excluir() {
		final Scanner leitorOrganizador = new Scanner(System.in);
		System.out.println("****************Exclusão do organizador********************");
		System.out.println("Informe o código do organizador que deseja excluir:");
		final int codigo = leitorOrganizador.nextInt();

		final OrganizadorEntity organizadorEntity = this.organizadorRepository.consultarPorCodigo(codigo);

		if (organizadorEntity.getCodigo() == codigo) {
			this.organizadorRepository.excluir(organizadorEntity);
			System.out.println("O registro foi deletado com sucesso!");
		}
	}

	public OrganizadorEntity alterar() {
		final Scanner leitorOrganizador = new Scanner(System.in);
		System.out.println("****************Alteração do organizador********************");
		System.out.println("Informe o código do organizador que deseja alterar:");
		final int codigo = leitorOrganizador.nextInt();

		final OrganizadorEntity organizadorEntity = this.organizadorRepository.consultarPorCodigo(codigo);

		if (organizadorEntity.getCodigo() == codigo) {
			System.out.println("Informe o novo nome:");
			organizadorEntity.setNome(leitorOrganizador.next());
			System.out.println("Informe o código do organizador:");
			organizadorEntity.setCodigo(leitorOrganizador.nextInt());
			System.out.println("Informe o evento criado:");
			organizadorEntity.setEventoCriado(leitorOrganizador.next());
			System.out.println("Informe a descricao:");
			organizadorEntity.setDescricao(leitorOrganizador.next());
			System.out.println("Informe o nível do organizador :");
			organizadorEntity.setNivelOrganizador(leitorOrganizador.nextInt());
			this.organizadorRepository.alterar(organizadorEntity);
			System.out.println("Alterado com Sucesso");

		} else {
			System.out.println("Não existe organizador com esse código!");
		}

		return organizadorEntity;
	}

}
