package service;

import java.util.List;
import java.util.Scanner;

import entity.EsporteEntity;
import repository.EsporteRepository;

public class EsporteService {

	EsporteRepository esporteRepository;

	public EsporteService() {
		this.esporteRepository = new EsporteRepository();
	}

	public int processaMenu() {

		final Scanner leitorEsporte = new Scanner(System.in);
		final List<String> menu = this.esporteRepository.consultarMenu();
		for (final String string : menu) {
			System.out.println(string);
		}

		final int opcao = leitorEsporte.nextInt();
		return opcao;
	}

	public void cadastrar() {
		final Scanner leitura = new Scanner(System.in);
		System.out.println("************Cadastro esporte**************");

		System.out.println("Informe o nome do esporte:");
		final String nome = leitura.next();
		System.out.println("Informe a quantidade de participantes:");
		final int qtdParticipantes = leitura.nextInt();
		System.out.println("Informe o código do esporte:");
		final int codigoEsporte = leitura.nextInt();
		System.out.println("Informe a regra do esporte:");
		final String regra = leitura.next();
		System.out.println("Informe a data de criação:");
		final String dataCriacao = leitura.next();

		final EsporteEntity esporteEntity = new EsporteEntity(nome, qtdParticipantes, codigoEsporte, regra,
				dataCriacao);

		this.esporteRepository.incluir(esporteEntity);
	}

	public List<EsporteEntity> consultarTodos() {
		final List<EsporteEntity> esportes = this.esporteRepository.consultarTodos();

		if (esportes.isEmpty()) {
			System.out.println("Não existe esportes cadastrados!");
			System.out.println("\n\n\n");
		} else {
			for (int i = 0; i < esportes.size(); i++) {

				System.out.println("\n\n\n\n\n\n\n\n\n");
				System.out.println("******Consulta Esporte********");
				System.out.println("********  Dados do esporte ********");
				System.out.println("Nome da esporte: " + esportes.get(i).getNome());
				System.out.println("Qtd participantes:" + esportes.get(i).getQtdParticipantes());
				System.out.println("código do esporte:" + esportes.get(i).getCodigo());
				System.out.println("Regra: " + esportes.get(i).getRegra());
				System.out.println("Data de criação: " + esportes.get(i).getDataCriacao());
				System.out.println("**********************************");
				System.out.println("\n\n\n");

			}
		}

		return esportes;
	}

	public EsporteEntity consultarPorCodigo() {

		final Scanner leitorEsporte = new Scanner(System.in);
		System.out.println("************Consultar por c�digo do esporte**************");

		System.out.println("Informe o código:");
		final int codigo = leitorEsporte.nextInt();

		final EsporteEntity esporte = this.esporteRepository.consultarPorCodigo(codigo);

		if (esporte == null) {
			System.out.println("Não existe esportes cadastrados!");
			System.out.println("\n\n\n");
		} else {
			System.out.println("\n\n\n\n\n\n\n\n\n");
			System.out.println("******Consulta Esporte********");
			System.out.println("********  Dados do esporte ********");
			System.out.println("Nome da esporte: " + esporte.getNome());
			System.out.println("Qtd participantes:" + esporte.getQtdParticipantes());
			System.out.println("código do esporte:" + esporte.getCodigo());
			System.out.println("Regra: " + esporte.getRegra());
			System.out.println("Data de criação: " + esporte.getDataCriacao());
			System.out.println("**********************************");
			System.out.println("\n\n\n");
		}
		return esporte;
	}

	public void excluir() {
		final Scanner leitorEsporte = new Scanner(System.in);

		System.out.println("****************Exclusão do Esporte********************");
		System.out.println("Informe o código do esporte que deseja excluir:");
		final int codigo = leitorEsporte.nextInt();

		final EsporteEntity esporteEntity = this.esporteRepository.consultarPorCodigo(codigo);
		if (esporteEntity != null) {

			this.esporteRepository.excluir(esporteEntity);
			System.out.println("O registro foi deletado com sucesso!");

		}

	}

	public void alterar() {
		final Scanner leitorEsporte = new Scanner(System.in);
		System.out.println("****************Alteração do esporte********************");
		System.out.println("Informe o código do esporte que deseja alterar:");
		final int codigo = leitorEsporte.nextInt();

		final EsporteEntity esporteEntity = this.esporteRepository.consultarPorCodigo(codigo);

		if (esporteEntity != null) {

			System.out.println("Informe o novo nome:");
			esporteEntity.setNome(leitorEsporte.next());
			System.out.println("Informe a quantidade de participantes:");
			esporteEntity.setQtdParticipantes(leitorEsporte.nextInt());
			System.out.println("Informe o código do esporte:");
			esporteEntity.setCodigo(leitorEsporte.nextInt());
			System.out.println("Informe a regra:");
			esporteEntity.setRegra(leitorEsporte.next());
			System.out.println("Informe a data de criação :");
			esporteEntity.setDataCriacao(leitorEsporte.next());

			this.esporteRepository.alterar(esporteEntity);
			System.out.println("Alterado com Sucesso");

		} else {
			System.out.println("Não existe esporte com esse código!");
		}
	}

}
